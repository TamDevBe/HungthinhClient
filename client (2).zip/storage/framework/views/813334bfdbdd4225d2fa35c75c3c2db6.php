
<?php $__env->startSection('title', 'Trang chủ'); ?>
<?php $__env->startSection('subtitle', 'Đăng nhập'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container bg-light rounded shadow-sm mt-5" style="max-width: 400px">
        <div class="container p-5 text-center"><img src="./logo/HungThinh.png" class="img-fluid "
                style="width:150px; height:auto" alt="">
        </div>
        <h3 class="text-center mb-4">Đăng Nhập</h3>

        
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($err); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        
        <form method="POST" action="<?php echo e(route('login.submit')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label>Email</label>
                <input type="email" name="email" class="form-control" placeholder="Nhập email" required>
            </div>
            <div class="mb-3">
                <label>Mật khẩu</label>
                <input type="password" name="password" class="form-control" placeholder="Nhập mật khẩu" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Đăng nhập</button>
        </form>

        <div class="mt-3 text-center">
            <span>Bạn chưa có tài khoản? <a href="<?php echo e(route('register.form')); ?>">Đăng ký</a></span>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            }
        });

        document.addEventListener('DOMContentLoaded', function() {
            if (localStorage.getItem('data')) {
                $.post('/yeuthich/dong-bo', {
                    Yeuthich: JSON.parse(localStorage.getItem('data'))
                }, function(res) {
                    localStorage.removeItem('data');
                    console.log('Đã đồng bộ danh sách yêu thích lên server');
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/op6cjaieob0f/public_html/resources/views/pages/Login.blade.php ENDPATH**/ ?>