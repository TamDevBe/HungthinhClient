<?php $__env->startSection('title', 'Trang chủ'); ?>
<?php $__env->startSection('subtitle', 'Đổi mật khẩu'); ?>
<?php $__env->startSection('profile_content'); ?>
    <div class="container py-5">
        <div class="container rounded shadow-sm p-2 d-flex align-items-center bg-white mb-4">
            <h4 class="title-profile">Đặt lại mật khẩu</h4>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($err); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('profile.sendResetOtp')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" name="email" id="email" class="form-control" placeholder="Nhập email" required
                    value="<?php echo e(old('email')); ?>">
            </div>
            <button type="submit" class="btn btn-primary w-100">Gửi mã xác thực</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Profile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/op6cjaieob0f/public_html/resources/views/profile/SentRePassEmail.blade.php ENDPATH**/ ?>