
<?php $__env->startSection('title', 'Trang chủ'); ?>
<?php $__env->startSection('content'); ?>
    <h2>Không tìm thấy kết quả nào cho: "<?php echo e($kyw); ?>"</h2>
    <p>Vui lòng thử lại với từ khóa khác.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/op6cjaieob0f/public_html/resources/views/pages/search.blade.php ENDPATH**/ ?>