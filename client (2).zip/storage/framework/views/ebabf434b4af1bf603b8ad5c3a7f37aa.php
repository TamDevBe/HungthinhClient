
<?php $__env->startSection('title', 'Trang chủ'); ?>
<?php $__env->startSection('subtitle', 'Bài viết'); ?>
<?php $__env->startSection('url', route('baiviet.index')); ?>
<?php $__env->startSection('subsubtitle', 'Bài viết chi tiết'); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .post-body img {
            max-width: 100%;
            height: auto;
            border-radius: var(--bs-border-radius, 0.25rem);
            margin-top: 1rem;
            margin-bottom: 1rem;
            display: block;
            margin-left: auto;
            margin-right: auto;
            box-shadow: var(--bs-box-shadow-sm);
        }
    </style>

    <div class="container my-4 my-md-5">
        <div class="row g-4 g-lg-5">
            <!-- Cột trái: Nội dung bài viết -->
            <div class="col-12 col-lg-9">
                <div class="bg-white p-4 p-lg-5 rounded shadow-sm">
                    <h1 class="display-6 fw-bold text-dark mb-3"><?php echo e($baiviet->tieude); ?></h1>

                    <div
                        class="text-muted mb-4 pb-2 d-flex flex-column flex-sm-row align-items-start align-sm-center border-bottom gap-2">
                        <span class="me-4">
                            <i class="fas fa-folder me-1 text-info"></i>
                            Danh mục: <span class="badge bg-info text-dark"><?php echo e($baiviet->danhmuc->tendm); ?></span>
                        </span>
                        <span class="me-4">
                            <i class="fas fa-calendar-alt me-1 text-secondary"></i>
                            Ngày đăng: <?php echo e($baiviet->created_at->format('d/m/Y')); ?>

                        </span>
                        <span class="me-4">
                            <i class="fas fa-user me-1 text-secondary"></i>
                            Tác giả: <?php echo e($baiviet->user->hoten ?? 'Admin'); ?>

                        </span>
                    </div>

                    <?php if($baiviet->motangan): ?>
                        <p class="lead fst-italic border-start border-4 border-info ps-3 mb-4 text-dark">
                            <?php echo e($baiviet->motangan); ?>

                        </p>
                    <?php endif; ?>

                    <div class="post-body text-dark" style="line-height: 1.7;">
                        <?php echo $baiviet->noidung; ?>

                    </div>
                </div>

                <div class="d-block d-lg-none mt-4">
                    <div class="bg-white shadow-sm rounded p-3">
                        <h5 class="fw-bold mb-3">Bài viết liên quan</h5>
                        <?php $__currentLoopData = $baivietLienQuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-3">
                                <?php echo $__env->make('baiviet-partials.card', ['post' => $post, 'type' => 'list'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 d-none d-lg-block">
                <div class="bg-white shadow-sm rounded p-3">
                    <h5 class="fw-bold mb-3">Bài viết liên quan</h5>
                    <?php $__currentLoopData = $baivietLienQuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col">
                            <?php echo $__env->make('baiviet-partials.card', ['post' => $post], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/op6cjaieob0f/public_html/resources/views/baiviet-partials/ShowBaiviet.blade.php ENDPATH**/ ?>