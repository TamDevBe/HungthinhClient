<div class="col-md-3 order-md-last baiviet-sidebar">
    <div class="bg-white shadow-sm rounded p-3 mb-4">
        <h5 class="fw-bold mb-3">Danh mục bài viết</h5>
        <ul class="list-unstyled baiviet-danhmuc-list">
            <?php $__currentLoopData = $danhmuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="mb-2">
                    <a href="<?php echo e(route('baiviet.danhmuc', $dm->id)); ?>"
                        class="btn btn-link p-0 text-start text-decoration-none <?php echo e(isset($danhmucChon) && $danhmucChon->id == $dm->id ? 'fw-bold text-primary' : ''); ?>">
                        <?php echo e($dm->tendm); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    <div class="bg-white shadow-sm rounded p-3 mb-4 baiviet-xemnhanh">
        <h5 class="fw-bold">Bài viết xem nhanh</h5>
        <?php $__currentLoopData = \App\Models\Baiviet::orderBy('created_at', 'desc')->limit(3)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-2">
                <a href="<?php echo e(route('baiviet.show', $bv->slug)); ?>">
                    <strong><?php echo e($bv->tieude); ?></strong>
                </a>
                <p class="text-muted small mb-0"><?php echo e(\Illuminate\Support\Str::limit(strip_tags($bv->noidung), 60)); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH /home/op6cjaieob0f/public_html/resources/views/pages/SidebarBaiviet.blade.php ENDPATH**/ ?>