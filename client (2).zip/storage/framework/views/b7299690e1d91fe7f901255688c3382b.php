
<?php $__env->startSection('title', 'Trang chủ'); ?>
<?php $__env->startSection('subtitle', 'Thông tin cá nhân'); ?>
<?php $__env->startSection('subsubtitle', 'Đơn hàng của tôi'); ?>
<?php $__env->startSection('subtitle_url'); ?>
    <?php echo e(route('profile.profileUser')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('profile_content'); ?>
    <div class="pt-3">
        <!-- Title -->
        <div class="container rounded shadow-sm p-2 d-flex align-items-center bg-white mb-4">
            <h4 class="title-profile mb-0 fs-4 fs-md-3">My Order</h4>
        </div>

        <!-- Tabs using Bootstrap 5 nav-pills -->
        <div class="container">
            <ul class="nav nav-pills mb-3 flex-wrap" id="pills-tab" role="tablist">
                <li class="nav-item me-2 mb-2" role="presentation">
                    <button class="nav-link active px-3 py-2" id="pills-tatca-tab" data-bs-toggle="pill"
                        data-bs-target="#pills-tatca" type="button" role="tab" aria-controls="pills-tatca"
                        aria-selected="true">Tất cả</button>
                </li>
                <li class="nav-item me-2 mb-2" role="presentation">
                    <button class="nav-link px-3 py-2" id="pills-pending-tab" data-bs-toggle="pill"
                        data-bs-target="#pills-pending" type="button" role="tab" aria-controls="pills-pending"
                        aria-selected="false">Chờ xác nhận</button>
                </li>
                <li class="nav-item me-2 mb-2" role="presentation">
                    <button class="nav-link px-3 py-2" id="pills-confirmed-tab" data-bs-toggle="pill"
                        data-bs-target="#pills-confirmed" type="button" role="tab" aria-controls="pills-confirmed"
                        aria-selected="false">Đã xác nhận</button>
                </li>
                <li class="nav-item me-2 mb-2" role="presentation">
                    <button class="nav-link px-3 py-2" id="pills-shipping-tab" data-bs-toggle="pill"
                        data-bs-target="#pills-shipping" type="button" role="tab" aria-controls="pills-shipping"
                        aria-selected="false">Đang giao</button>
                </li>
                <li class="nav-item me-2 mb-2" role="presentation">
                    <button class="nav-link px-3 py-2" id="pills-done-tab" data-bs-toggle="pill"
                        data-bs-target="#pills-done" type="button" role="tab" aria-controls="pills-done"
                        aria-selected="false">Hoàn thành</button>
                </li>
                <li class="nav-item me-2 mb-2" role="presentation">
                    <button class="nav-link px-3 py-2" id="pills-cancelled-tab" data-bs-toggle="pill"
                        data-bs-target="#pills-cancelled" type="button" role="tab" aria-controls="pills-cancelled"
                        aria-selected="false">Đã huỷ</button>
                </li>
            </ul>

            <div class="input-group mb-4">
                <input type="text" class="form-control" placeholder="Tìm đơn hàng theo Mã đơn hàng" id="search-input"
                    name="search" value="<?php echo e($search ?? ''); ?>">
                <button class="btn btn-outline-primary" type="button" id="search-button">Tìm đơn hàng</button>
            </div>

            <!-- Tab content -->
            <div class="tab-content mb-4" id="pills-tabContent">
                <!-- All Orders Tab -->
                <div class="tab-pane fade show active" id="pills-tatca" role="tabpanel" aria-labelledby="pills-tatca-tab"
                    tabindex="0">
                    <?php if($orderAll->isEmpty()): ?>
                        <div class="order-empty text-center py-5">
                            <img src="https://cdn-icons-png.flaticon.com/512/2748/2748558.png" alt="Empty"
                                class="img-fluid" style="max-width: 150px;">
                            <p class="mt-3">Quý khách chưa có đơn hàng nào.</p>
                            <a href="#" class="btn btn-danger mt-2">TIẾP TỤC MUA HÀNG</a>
                        </div>
                    <?php else: ?>
                        <div class="accordion accordion-flush" id="accordionAll">
                            <?php $__currentLoopData = $orderAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#flush-all-<?php echo e($order->id); ?>" aria-expanded="false"
                                            aria-controls="flush-all-<?php echo e($order->id); ?>">
                                            <div
                                                class="w-100 d-flex flex-wrap justify-content-between align-items-center gap-2">
                                                <span class="fs-6 fw-bold">#MD<?php echo e($order->id); ?></span>
                                                <span class="fs-6"><?php echo e($order->created_at->format('d.m.Y')); ?></span>
                                                <span
                                                    class="badge text-uppercase
                                                    <?php if($order->trangthai == 'chờ xác nhận'): ?> bg-warning 
                                                    <?php elseif($order->trangthai == 'đã xác nhận'): ?> bg-info 
                                                    <?php elseif($order->trangthai == 'đang giao'): ?> bg-primary 
                                                    <?php elseif($order->trangthai == 'hoàn thành'): ?> bg-success 
                                                    <?php else: ?> bg-danger <?php endif; ?> fs-6"
                                                    style="width: 150px;">
                                                    <?php echo e($order->trangthai); ?>

                                                </span>
                                                <span class="fs-6"><?php echo e(number_format($order->tongtien, 0, ',', '.')); ?>

                                                    VNĐ</span>
                                            </div>
                                        </button>
                                    </h2>
                                    <div id="flush-all-<?php echo e($order->id); ?>" class="accordion-collapse collapse"
                                        data-bs-parent="#accordionAll">
                                        <div class="accordion-body">
                                            <!-- Order Details -->
                                            <div class="table-responsive">
                                                <table class="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>Hình</th>
                                                            <th>Sản phẩm</th>
                                                            <th>Giá</th>
                                                            <th>Số lượng</th>
                                                            <th>Tổng</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $order->donhangchitiet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td>
                                                                    <img src="<?php echo e(asset('storage/' . $item->bienthe->hinh)); ?>"
                                                                        alt="" style="width:100px; height: auto;">
                                                                </td>
                                                                <td><?php echo e($item->bienthe->sanpham->tensp); ?></td>
                                                                <td><?php echo e(number_format($item->gia, 0, ',', '.')); ?> VNĐ</td>
                                                                <td><?php echo e($item->soluong); ?></td>
                                                                <td><?php echo e(number_format($item->gia * $item->soluong, 0, ',', '.')); ?>

                                                                    VNĐ</td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <td colspan="4" class="text-end">Thành tiền</td>
                                                            <td><?php echo e(number_format($order->tongtien, 0, ',', '.')); ?> VNĐ</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4" class="text-end">Vận chuyển</td>
                                                            <td><?php echo e(number_format(30000, 0, ',', '.')); ?> VNĐ</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4" class="text-end"><strong>Total</strong>
                                                            </td>
                                                            <td><strong><?php echo e(number_format($order->tongtien + 30000, 0, ',', '.')); ?>

                                                                    VNĐ</strong></td>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                            <div class="d-flex justify-content-end flex-wrap gap-2 mt-3">

                                                <?php if($order->trangthai == 'chờ xác nhận'): ?>
                                                    <form action="<?php echo e(route('donhang.huy', $order->id)); ?>" method="POST"
                                                        class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PATCH'); ?>
                                                        <button type="submit" class="btn btn-danger">Hủy đơn</button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- chờ duyệt -->
                <div class="tab-pane fade" id="pills-pending" role="tabpanel" aria-labelledby="pills-pending-tab"
                    tabindex="0">
                    <?php if($pendingOrders->isEmpty()): ?>
                        <div class="order-empty text-center py-5">
                            <img src="https://cdn-icons-png.flaticon.com/512/2748/2748558.png" alt="Empty"
                                class="img-fluid" style="max-width: 150px;">
                            <p class="mt-3">Quý khách chưa có đơn hàng nào.</p>
                            <a href="#" class="btn btn-danger mt-2">TIẾP TỤC MUA HÀNG</a>
                        </div>
                    <?php else: ?>
                        <div class="accordion accordion-flush" id="accordionPending">
                            <?php $__currentLoopData = $pendingOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#flush-pending-<?php echo e($order->id); ?>"
                                            aria-expanded="false" aria-controls="flush-pending-<?php echo e($order->id); ?>">
                                            <div
                                                class="w-100 d-flex flex-wrap justify-content-between align-items-center gap-2">
                                                <span class="fs-6 fw-bold">#MD<?php echo e($order->id); ?></span>
                                                <span class="fs-6"><?php echo e($order->created_at->format('d.m.Y')); ?></span>
                                                <span
                                                    class="badge bg-warning fs-6"><?php echo e(strtoupper($order->trangthai)); ?></span>
                                                <span class="fs-6"><?php echo e(number_format($order->tongtien, 0, ',', '.')); ?>

                                                    VNĐ</span>
                                            </div>
                                        </button>
                                    </h2>
                                    <div id="flush-pending-<?php echo e($order->id); ?>" class="accordion-collapse collapse"
                                        data-bs-parent="#accordionPending">
                                        <div class="accordion-body">
                                            <!-- Order Details -->
                                            <div class="table-responsive">
                                                <table class="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>Hình</th>
                                                            <th>Sản phẩm</th>
                                                            <th>Giá</th>
                                                            <th>Số lượng</th>
                                                            <th>Tổng</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $order->donhangchitiet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td>
                                                                    <img src="<?php echo e(asset('storage/' . $item->bienthe->hinh)); ?>"
                                                                        alt="" style="width:100px; height: auto;">
                                                                </td>
                                                                <td><?php echo e($item->bienthe->sanpham->tensp); ?></td>
                                                                <td><?php echo e(number_format($item->gia, 0, ',', '.')); ?> VNĐ</td>
                                                                <td><?php echo e($item->soluong); ?></td>
                                                                <td><?php echo e(number_format($item->gia * $item->soluong, 0, ',', '.')); ?>

                                                                    VNĐ</td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <td colspan="4" class="text-end">Thành tiền</td>
                                                            <td><?php echo e(number_format($order->tongtien, 0, ',', '.')); ?> VNĐ</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4" class="text-end">Vận chuyển</td>
                                                            <td><?php echo e(number_format(30000, 0, ',', '.')); ?> VNĐ</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4" class="text-end"><strong>Total</strong>
                                                            </td>
                                                            <td><strong><?php echo e(number_format($order->tongtien + 30000, 0, ',', '.')); ?>

                                                                    VNĐ</strong></td>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                            <div class="d-flex justify-content-end flex-wrap gap-2 mt-3">

                                                <?php if($order->trangthai == 'chờ xác nhận'): ?>
                                                    <form action="<?php echo e(route('donhang.huy', $order->id)); ?>" method="POST"
                                                        class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PATCH'); ?>
                                                        <button type="submit" class="btn btn-danger">Hủy đơn</button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- đã duyệt -->
                <div class="tab-pane fade" id="pills-confirmed" role="tabpanel" aria-labelledby="pills-confirmed-tab"
                    tabindex="0">
                    <?php if($confirmedOrders->isEmpty()): ?>
                        <div class="order-empty text-center py-5">
                            <img src="https://cdn-icons-png.flaticon.com/512/2748/2748558.png" alt="Empty"
                                class="img-fluid" style="max-width: 150px;">
                            <p class="mt-3">Quý khách chưa có đơn hàng nào.</p>
                            <a href="#" class="btn btn-danger mt-2">TIẾP TỤC MUA HÀNG</a>
                        </div>
                    <?php else: ?>
                        <div class="accordion accordion-flush" id="accordionConfirmed">
                            <?php $__currentLoopData = $confirmedOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse"
                                            data-bs-target="#flush-confirmed-<?php echo e($order->id); ?>" aria-expanded="false"
                                            aria-controls="flush-confirmed-<?php echo e($order->id); ?>">
                                            <div
                                                class="w-100 d-flex flex-wrap justify-content-between align-items-center gap-2">
                                                <span class="fs-6 fw-bold">#MD<?php echo e($order->id); ?></span>
                                                <span class="fs-6"><?php echo e($order->created_at->format('d.m.Y')); ?></span>
                                                <span
                                                    class="badge bg-info fs-6"><?php echo e(strtoupper($order->trangthai)); ?></span>
                                                <span class="fs-6"><?php echo e(number_format($order->tongtien, 0, ',', '.')); ?>

                                                    VNĐ</span>
                                            </div>
                                        </button>
                                    </h2>
                                    <div id="flush-confirmed-<?php echo e($order->id); ?>" class="accordion-collapse collapse"
                                        data-bs-parent="#accordionConfirmed">
                                        <div class="accordion-body">
                                            <!-- Order Details -->
                                            <div class="table-responsive">
                                                <table class="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>Hình</th>
                                                            <th>Sản phẩm</th>
                                                            <th>Giá</th>
                                                            <th>Số lượng</th>
                                                            <th>Tổng</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $order->donhangchitiet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td>
                                                                    <img src="<?php echo e(asset('storage/' . $item->bienthe->hinh)); ?>"
                                                                        alt="" style="width:100px; height: auto;">
                                                                </td>
                                                                <td><?php echo e($item->bienthe->sanpham->tensp); ?></td>
                                                                <td><?php echo e(number_format($item->gia, 0, ',', '.')); ?> VNĐ</td>
                                                                <td><?php echo e($item->soluong); ?></td>
                                                                <td><?php echo e(number_format($item->gia * $item->soluong, 0, ',', '.')); ?>

                                                                    VNĐ</td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <td colspan="4" class="text-end">Thành tiền</td>
                                                            <td><?php echo e(number_format($order->tongtien, 0, ',', '.')); ?> VNĐ</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4" class="text-end">Vận chuyển</td>
                                                            <td><?php echo e(number_format(30000, 0, ',', '.')); ?> VNĐ</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4" class="text-end"><strong>Total</strong>
                                                            </td>
                                                            <td><strong><?php echo e(number_format($order->tongtien + 30000, 0, ',', '.')); ?>

                                                                    VNĐ</strong></td>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- đang giao -->
                <div class="tab-pane fade" id="pills-shipping" role="tabpanel" aria-labelledby="pills-shipping-tab"
                    tabindex="0">
                    <?php if($shippingOrders->isEmpty()): ?>
                        <div class="order-empty text-center py-5">
                            <img src="https://cdn-icons-png.flaticon.com/512/2748/2748558.png" alt="Empty"
                                class="img-fluid" style="max-width: 150px;">
                            <p class="mt-3">Quý khách chưa có đơn hàng nào.</p>
                            <a href="#" class="btn btn-danger mt-2">TIẾP TỤC MUA HÀNG</a>
                        </div>
                    <?php else: ?>
                        <div class="accordion accordion-flush" id="accordionShipping">
                            <?php $__currentLoopData = $shippingOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse"
                                            data-bs-target="#flush-shipping-<?php echo e($order->id); ?>" aria-expanded="false"
                                            aria-controls="flush-shipping-<?php echo e($order->id); ?>">
                                            <div
                                                class="w-100 d-flex flex-wrap justify-content-between align-items-center gap-2">
                                                <span class="fs-6 fw-bold">#MD<?php echo e($order->id); ?></span>
                                                <span class="fs-6"><?php echo e($order->created_at->format('d.m.Y')); ?></span>
                                                <span
                                                    class="badge bg-primary fs-6"><?php echo e(strtoupper($order->trangthai)); ?></span>
                                                <span class="fs-6"><?php echo e(number_format($order->tongtien, 0, ',', '.')); ?>

                                                    VNĐ</span>
                                            </div>
                                        </button>
                                    </h2>
                                    <div id="flush-shipping-<?php echo e($order->id); ?>" class="accordion-collapse collapse"
                                        data-bs-parent="#accordionShipping">
                                        <div class="accordion-body">
                                            <!-- Order Details -->
                                            <div class="table-responsive">
                                                <table class="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>Hình</th>
                                                            <th>Sản phẩm</th>
                                                            <th>Giá</th>
                                                            <th>Số lượng</th>
                                                            <th>Tổng</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $order->donhangchitiet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td>
                                                                    <img src="<?php echo e(asset('storage/' . $item->bienthe->hinh)); ?>"
                                                                        alt="" style="width:100px; height: auto;">
                                                                </td>
                                                                <td><?php echo e($item->bienthe->sanpham->tensp); ?></td>
                                                                <td><?php echo e(number_format($item->gia, 0, ',', '.')); ?> VNĐ</td>
                                                                <td><?php echo e($item->soluong); ?></td>
                                                                <td><?php echo e(number_format($item->gia * $item->soluong, 0, ',', '.')); ?>

                                                                    VNĐ</td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <td colspan="4" class="text-end">Thành tiền</td>
                                                            <td><?php echo e(number_format($order->tongtien, 0, ',', '.')); ?> VNĐ</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4" class="text-end">Vận chuyển</td>
                                                            <td><?php echo e(number_format(30000, 0, ',', '.')); ?> VNĐ</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4" class="text-end"><strong>Total</strong>
                                                            </td>
                                                            <td><strong><?php echo e(number_format($order->tongtien + 30000, 0, ',', '.')); ?>

                                                                    VNĐ</strong></td>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- hoàn thành -->
                <div class="tab-pane fade" id="pills-done" role="tabpanel" aria-labelledby="pills-done-tab"
                    tabindex="0">
                    <?php if($doneOrders->isEmpty()): ?>
                        <div class="order-empty text-center py-5">
                            <img src="https://cdn-icons-png.flaticon.com/512/2748/2748558.png" alt="Empty"
                                class="img-fluid" style="max-width: 150px;">
                            <p class="mt-3">Quý khách chưa có đơn hàng nào.</p>
                            <a href="#" class="btn btn-danger mt-2">TIẾP TỤC MUA HÀNG</a>
                        </div>
                    <?php else: ?>
                        <div class="accordion accordion-flush" id="accordionDone">
                            <?php $__currentLoopData = $doneOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#flush-done-<?php echo e($order->id); ?>"
                                            aria-expanded="false" aria-controls="flush-done-<?php echo e($order->id); ?>">
                                            <div
                                                class="w-100 d-flex flex-wrap justify-content-between align-items-center gap-2">
                                                <span class="fs-6 fw-bold">#MD<?php echo e($order->id); ?></span>
                                                <span class="fs-6"><?php echo e($order->created_at->format('d.m.Y')); ?></span>
                                                <span
                                                    class="badge bg-success fs-6"><?php echo e(strtoupper($order->trangthai)); ?></span>
                                                <span class="fs-6"><?php echo e(number_format($order->tongtien, 0, ',', '.')); ?>

                                                    VNĐ</span>
                                            </div>
                                        </button>
                                    </h2>
                                    <div id="flush-done-<?php echo e($order->id); ?>" class="accordion-collapse collapse"
                                        data-bs-parent="#accordionDone">
                                        <div class="accordion-body">
                                            <!-- Order Details -->
                                            <div class="table-responsive">
                                                <table class="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>Hình</th>
                                                            <th>Sản phẩm</th>
                                                            <th>Giá</th>
                                                            <th>Số lượng</th>
                                                            <th>Tổng</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $order->donhangchitiet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td>
                                                                    <img src="<?php echo e(asset('storage/' . $item->bienthe->hinh)); ?>"
                                                                        alt="" style="width:100px; height: auto;">
                                                                </td>
                                                                <td><?php echo e($item->bienthe->sanpham->tensp); ?></td>
                                                                <td><?php echo e(number_format($item->gia, 0, ',', '.')); ?> VNĐ</td>
                                                                <td><?php echo e($item->soluong); ?></td>
                                                                <td><?php echo e(number_format($item->gia * $item->soluong, 0, ',', '.')); ?>

                                                                    VNĐ</td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <td colspan="4" class="text-end">Thành tiền</td>
                                                            <td><?php echo e(number_format($order->tongtien, 0, ',', '.')); ?> VNĐ</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4" class="text-end">Vận chuyển</td>
                                                            <td><?php echo e(number_format(30000, 0, ',', '.')); ?> VNĐ</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4" class="text-end"><strong>Total</strong>
                                                            </td>
                                                            <td><strong><?php echo e(number_format($order->tongtien + 30000, 0, ',', '.')); ?>

                                                                    VNĐ</strong></td>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- hủy -->
                <div class="tab-pane fade" id="pills-cancelled" role="tabpanel" aria-labelledby="pills-cancelled-tab"
                    tabindex="0">
                    <?php if($cancelledOrders->isEmpty()): ?>
                        <div class="order-empty text-center py-5">
                            <img src="https://cdn-icons-png.flaticon.com/512/2748/2748558.png" alt="Empty"
                                class="img-fluid" style="max-width: 150px;">
                            <p class="mt-3">Quý khách chưa có đơn hàng nào.</p>
                            <a href="#" class="btn btn-danger mt-2">TIẾP TỤC MUA HÀNG</a>
                        </div>
                    <?php else: ?>
                        <div class="accordion accordion-flush" id="accordionCancelled">
                            <?php $__currentLoopData = $cancelledOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse"
                                            data-bs-target="#flush-cancelled-<?php echo e($order->id); ?>" aria-expanded="false"
                                            aria-controls="flush-cancelled-<?php echo e($order->id); ?>">
                                            <div
                                                class="w-100 d-flex flex-wrap justify-content-between align-items-center gap-2">
                                                <span class="fs-6 fw-bold">#MD<?php echo e($order->id); ?></span>
                                                <span class="fs-6"><?php echo e($order->created_at->format('d.m.Y')); ?></span>
                                                <span
                                                    class="badge bg-danger fs-6"><?php echo e(strtoupper($order->trangthai)); ?></span>
                                                <span class="fs-6"><?php echo e(number_format($order->tongtien, 0, ',', '.')); ?>

                                                    VNĐ</span>
                                            </div>
                                        </button>
                                    </h2>
                                    <div id="flush-cancelled-<?php echo e($order->id); ?>" class="accordion-collapse collapse"
                                        data-bs-parent="#accordionCancelled">
                                        <div class="accordion-body">
                                            <!-- Order Details -->
                                            <div class="table-responsive">
                                                <table class="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>Hình</th>
                                                            <th>Sản phẩm</th>
                                                            <th>Giá</th>
                                                            <th>Số lượng</th>
                                                            <th>Tổng</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $order->donhangchitiet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td>
                                                                    <img src="<?php echo e(asset('storage/' . $item->bienthe->hinh)); ?>"
                                                                        alt="" style="width:100px; height: auto;">
                                                                </td>
                                                                <td><?php echo e($item->bienthe->sanpham->tensp); ?></td>
                                                                <td><?php echo e(number_format($item->gia, 0, ',', '.')); ?> VNĐ</td>
                                                                <td><?php echo e($item->soluong); ?></td>
                                                                <td><?php echo e(number_format($item->gia * $item->soluong, 0, ',', '.')); ?>

                                                                    VNĐ</td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <td colspan="4" class="text-end">Thành tiền</td>
                                                            <td><?php echo e(number_format($order->tongtien, 0, ',', '.')); ?> VNĐ</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4" class="text-end">Vận chuyển</td>
                                                            <td><?php echo e(number_format(30000, 0, ',', '.')); ?> VNĐ</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4" class="text-end"><strong>Total</strong>
                                                            </td>
                                                            <td><strong><?php echo e(number_format($order->tongtien + 30000, 0, ',', '.')); ?>

                                                                    VNĐ</strong></td>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        document.getElementById('search-button').addEventListener('click', function() {
            const searchValue = document.getElementById('search-input').value;
            const url = new URL(window.location.href);
            if (searchValue) {
                url.searchParams.set('search', searchValue);
            } else {
                url.searchParams.delete('search');
            }
            window.location.href = url.toString();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Profile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/op6cjaieob0f/public_html/resources/views/profile/MyOrder.blade.php ENDPATH**/ ?>