
<?php $__env->startSection('content'); ?>
    <h2>Xác minh OTP</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('verify.form')); ?>">
        <?php echo csrf_field(); ?>
        <input type="text" name="otp_code" placeholder="Nhập mã OTP" class="form-control mb-2">
        <?php $__errorArgs = ['otp_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <button type="submit" class="btn btn-success">Xác thực</button>
    </form>

    <p>Mã xác thực hết hạn sau: <span id="countdown"></span></p>

    <form method="POST" action="<?php echo e(route('verify.resend')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-primary" id="resendBtn" disabled>Gửi lại mã</button>
    </form>
    <script>
        const expireTime = "<?php echo e(\Carbon\Carbon::parse(session('register_otp_expires'))->timestamp); ?>";
        const countdownEl = document.getElementById("countdown");
        const resendBtn = document.getElementById("resendBtn");

        function updateCountdown() {
            const now = Math.floor(Date.now() / 1000);
            let diff = expireTime - now;

            if (diff <= 0) {
                countdownEl.textContent = "Mã đã hết hạn";
                resendBtn.disabled = false;
                return;
            }

            const minutes = Math.floor(diff / 60).toString().padStart(2, '0');
            const seconds = (diff % 60).toString().padStart(2, '0');
            countdownEl.textContent = `${minutes}:${seconds}`;
        }

        updateCountdown();
        setInterval(updateCountdown, 1000);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/op6cjaieob0f/public_html/resources/views/Formverify.blade.php ENDPATH**/ ?>