
<?php $__env->startSection('title', 'Trang chủ'); ?>
<?php $__env->startSection('subtitle', 'Bài viết'); ?>
<?php $__env->startSection('subtitle_url'); ?>
    <?php echo e(route('baiviet.index')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subsubtitle', $danhmucChon->tendm ?? 'Tất cả bài viết'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container my-4">

        <form action="<?php echo e(route('baiviet.search')); ?>" method="GET" class="mb-4 d-flex gap-2 flex-column flex-md-row align-items-stretch">
            <input type="hidden" name="danhmuc" value="<?php echo e($danhmucChon->id ?? ''); ?>">
            <input type="text" name="keyword" value="<?php echo e(request('keyword')); ?>" placeholder="Tìm bài viết..."
                class="form-control flex-grow-1">
            <button type="submit" class="btn text-white flex-shrink-0" style="background-color: orange; border: none;">
                Tìm
            </button>
        </form>

        <div class="row g-4">

            <div class="col-md-9">

                <?php if(($baiVietChinh ?? null) || ($baiVietPhu->count() ?? 0) > 0 || ($baiViet->count() ?? 0) > 0): ?>

                    <div class="featured-articles mb-5 bg-white shadow-sm rounded p-3">
                        <h4 class="fw-bold mb-3">
                             <?php if($danhmucChon): ?>
                                 Bài viết thuộc danh mục: <?php echo e($danhmucChon->tendm); ?>

                             <?php else: ?>
                                 Danh sách bài viết
                             <?php endif; ?>
                         </h4>

                        <?php if($baiVietChinh ?? null): ?>
                            <div class="main-featured-article row g-3 mb-4">
                                <div class="col-md-6">
                                    <?php if($baiVietChinh->anhdaidien): ?>
                                        <a href="<?php echo e(route('baiviet.show', $baiVietChinh->slug)); ?>" class="d-block h-100">
                                            <img src="<?php echo e(config('app.cms_url') . '/storage/' . $baiVietChinh->anhdaidien); ?>"
                                                class="img-fluid rounded main-featured-img" alt="<?php echo e($baiVietChinh->tieude); ?>">
                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('baiviet.show', $baiVietChinh->slug)); ?>" class="d-block h-100">
                                            <img src="<?php echo e(asset('images/placeholder.jpg')); ?>" 
                                                 class="img-fluid rounded main-featured-img" alt="<?php echo e($baiVietChinh->tieude); ?>">
                                        </a>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-6 d-flex flex-column justify-content-center p-3">
                                    <a href="<?php echo e(route('baiviet.show', $baiVietChinh->slug)); ?>"
                                        class="text-decoration-none text-dark">
                                        <h3 class="fw-bold mb-2"><?php echo e($baiVietChinh->tieude); ?></h3>
                                    </a>
                                    <p class="text-muted small mb-2">
                                        <?php echo e(\Illuminate\Support\Str::limit(strip_tags($baiVietChinh->noidung), 200)); ?></p>
                                    <p class="text-muted small mb-0"><?php echo e($baiVietChinh->created_at->format('d/m/Y')); ?> -
                                        <?php echo e($baiVietChinh->luotxem); ?> lượt xem</p>
                                </div>
                            </div>
                        <?php endif; ?>

                       <?php if(($baiVietPhu->count() ?? 0) > 0): ?>
                            <h5 class="fw-bold mb-3">Các bài nổi bật khác</h5>
                            <div class="small-featured-list row g-3">
                                <?php $__currentLoopData = $baiVietPhu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $smallPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <div class="col-12 col-sm-4 col-md-4">
                                         <a href="<?php echo e(route('baiviet.show', $smallPost->slug)); ?>" class="small-featured-card text-decoration-none text-dark d-block">
                                             <?php if($smallPost->anhdaidien): ?>
                                                 <img src="<?php echo e(config('app.cms_url') . '/storage/' . $smallPost->anhdaidien); ?>"
                                                     class="img-fluid rounded mb-2 small-featured-img" alt="<?php echo e($smallPost->tieude); ?>">
                                             <?php else: ?>
                                                 <img src="<?php echo e(asset('images/placeholder.jpg')); ?>" 
                                                      class="img-fluid rounded mb-2 small-featured-img" alt="<?php echo e($smallPost->tieude); ?>">
                                             <?php endif; ?>
                                             <h6 class="fw-bold mb-1"><?php echo e(\Illuminate\Support\Str::limit($smallPost->tieude, 50)); ?></h6>
                                             <p class="text-muted small mb-0"><?php echo e($smallPost->created_at->format('d/m/Y')); ?></p>
                                         </a>
                                     </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>

                    </div>

                    <div class="regular-articles-list bg-white shadow-sm rounded p-3 mb-5">
                        <h5 class="fw-bold mb-3">Các bài viết khác</h5>
                        <div class="row g-3">
                            <?php $__empty_1 = true; $__currentLoopData = $baiViet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-12">
                                    <?php echo $__env->make('baiviet-partials.card', ['post' => $post, 'type' => 'list'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php if(!($baiVietChinh ?? null) && ($baiVietPhu->count() ?? 0) === 0): ?>
                                    <div class="col-12">
                                        <p>Không có bài viết nào trong danh mục này.</p>
                                    </div>
                                <?php else: ?>
                                    <div class="col-12">
                                        <p>Đã hết bài viết trong danh mục này.</p>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                        <?php if(($baiViet->total() ?? 0) > ($baiViet->perPage() ?? 15)): ?>
                            <div class="d-flex justify-content-center mt-4">
                                <?php echo e($baiViet->links()); ?>

                            </div>
                        <?php endif; ?>

                    </div>
                <?php else: ?>
                    <div class="bg-white shadow-sm rounded p-3 mb-5 text-center">
                         <p class="mb-0">Không có bài viết nào trong danh mục này.</p>
                    </div>
                <?php endif; ?>

            </div>

                 <?php echo $__env->make('pages.SidebarBaiviet', [
                     'danhmuc' => $danhmuc,
                     'danhmucChon' => $danhmucChon ?? null,
                 ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<style>
    @media (max-width: 767.98px) {
        .baiviet-search-form {
            flex-direction: column;
            align-items: stretch;
        }
        .baiviet-search-form input[type="text"] {
            width: 100% !important;
        }
         .baiviet-search-form button {
            width: 100%;
        }
    }

    .main-featured-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .small-featured-img {
        width: 100%;
        aspect-ratio: 4 / 3;
        object-fit: cover;
        transition: transform 0.3s ease-in-out;
    }

     .small-featured-card:hover .small-featured-img {
         transform: scale(1.05);
     }
</style>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/op6cjaieob0f/public_html/resources/views/pages/Baivietdanhmuc.blade.php ENDPATH**/ ?>