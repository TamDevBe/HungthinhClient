<!DOCTYPE html>
<html>

<head>
    <title>Kết quả thanh toán</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <div class="card shadow-sm">
            <div class="card-body text-center">
                <?php if($status == 'success'): ?>
                    <h1 class="text-success">Thanh toán thành công!</h1>
                    <p><?php echo e($message); ?></p>
                <?php elseif($status == 'error'): ?>
                    <h1 class="text-danger">Thanh toán thất bại!</h1>
                    <p><?php echo e($message); ?></p>
                <?php else: ?>
                    <h1 class="text-info">Thông tin</h1>
                    <p><?php echo e($message); ?></p>
                <?php endif; ?>
                <a href="<?php echo e(route('sanpham.index')); ?>" class="btn btn-primary mt-3">Quay lại cửa hàng</a>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH /home/op6cjaieob0f/public_html/resources/views/Checkout.blade.php ENDPATH**/ ?>