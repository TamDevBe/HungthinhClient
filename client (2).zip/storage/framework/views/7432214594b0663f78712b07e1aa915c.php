
<?php $__env->startSection('title', 'Trang chủ'); ?>
<?php $__env->startSection('subtitle', 'Thông tin cá nhân'); ?>
<?php $__env->startSection('subsubtitle', 'Sản phẩm yêu thích'); ?>
<?php $__env->startSection('subtitle_url'); ?>
    <?php echo e(route('profile.profileUser')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <style>
        .btn-favorite {
            transition: all 0.3s;
        }

        .btn-favorite.favorited {
            color: red !important;
        }

        .btn-favorite:hover {
            background-color: #f8f9fa;
        }

        .btn-remove-favorite {
            z-index: 10;
            opacity: 0.9;
            transition: all 0.2s ease;
        }

        .btn-remove-favorite:hover {
            opacity: 1;
            transform: scale(1.1);
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('profile_content'); ?>
    <div class="pt-3">
        <div class="container rounded shadow-sm p-2 d-flex align-items-center bg-white mb-4">
            <h4 class="title-profile">Sản phẩm yêu thích</h4>
        </div>
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class=" col-md-3 mb-4">
                    <a href="<?php echo e(optional($item->bienthe?->sanpham)->id
                        ? route('sanpham.detail', ['id' => $item->bienthe->sanpham->id, 'id_bienthe' => $item->id_bienthe])
                        : route('sanpham.index')); ?>"
                        class="text-decoration-none">
                        <div class="card h-100 shadow-sm product-card" style="border-radius: 10px;">

                            <div class="position-relative overflow-hidden">
                                <button class="btn btn-sm btn-danger btn-remove-favorite position-absolute top-0 end-0 m-2"
                                    data-id="<?php echo e($item->id_bienthe); ?>" data-url="<?php echo e(url()->current()); ?>"
                                    title="Xóa khỏi yêu thích">
                                    <i class="bi bi-trash fs-4"></i>
                                </button>
                                <img src="<?php echo e($item->bienthe && $item->bienthe->hinh
                                    ? asset('storage/' . $item->bienthe->hinh)
                                    : 'https://via.placeholder.com/300x200?text=No+Image'); ?>"
                                    class="card-img-top product-image"
                                    alt="<?php echo e(optional($item->bienthe?->sanpham)->tensp ?? 'Sản phẩm không xác định'); ?>"
                                    style="height: 200px; object-fit: cover;">
                            </div>
                            <div class="card-body text-center position-relative d-flex flex-column">
                                <div class="d-flex justify-content-center align-items-center" style="height: 60px;">
                                    <h6 class="card-text mb-0" style="height: 50px;">
                                        <?php echo e(optional($item->bienthe?->sanpham)->tensp ?? 'Sản phẩm không xác định'); ?>

                                    </h6>
                                </div>
                                <p class="card-text text-success mb-0 product-price mt-auto">
                                    <?php echo e(number_format($item->bienthe?->gia ?? 0)); ?> đ
                                </p>
                                <form method="POST" action="<?php echo e(route('cart.add')); ?>" class="mt-2">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id_bienthe" value="<?php echo e($item->id_bienthe); ?>">
                                    <input type="hidden" name="soluong" value="1">
                                    <button type="submit" class="btn btn-primary w-100"
                                        style="background-color: #fe9705; border: none;">
                                        Mua ngay
                                    </button>
                                </form>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="container">
                    <div class="row justify-content-center align-items-center text-center mt-5">
                        <div class="col-md-6">
                            <h4 class="text-muted">Không có sản phẩm yêu thích nào.</h4>
                            <p class="text-muted">Hãy thêm sản phẩm vào danh sách yêu thích để theo dõi chúng.</p>
                            <a href="<?php echo e(route('sanpham.index')); ?>" class="btn btn-primary">Khám phá sản phẩm</a>
                        </div>
            <?php endif; ?>


        </div>
        
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.btn-favorite').forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    const id_bienthe = this.getAttribute('data-id');
                    const url = this.getAttribute('data-url');
                    const isFavorited = this.classList.contains('favorited');
                    const yeuthichAddUrl = '<?php echo e(route('yeuthich.add')); ?>';
                    const yeuthichRemoveUrl = '<?php echo e(route('yeuthich.remove')); ?>';
                    const endpoint = isFavorited ? yeuthichRemoveUrl : yeuthichAddUrl;

                    // Kiểm tra đăng nhập
                    <?php if(!Auth::check()): ?>
                        alert('Vui lòng đăng nhập để thêm/xóa yêu thích.');
                        window.location.href = '<?php echo e(route('login.form')); ?>';
                        return;
                    <?php endif; ?>

                    fetch(endpoint, {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                            },
                            body: JSON.stringify({
                                id_bienthe,
                                url
                            })
                        })
                        .then(response => {
                            if (!response.ok) {
                                throw new Error('Network response was not ok: ' + response
                                    .status);
                            }
                            return response.json();
                        })
                        .then(data => {
                            if (data.success) {
                                this.classList.toggle('favorited', data.favorited);
                                this.querySelector('i').classList.toggle('bi-heart-fill', data
                                    .favorited);
                                this.querySelector('i').classList.toggle('bi-heart', !data
                                    .favorited);
                                if (!data.favorited) {
                                    this.closest('.col-6.col-md-3.mb-4')?.remove();
                                    if (!document.querySelector('.col-6.col-md-3.mb-4')) {
                                        window.location.reload();
                                    }
                                }
                                document.querySelector('#favorites-count').textContent =
                                    `(${data.favoritesCount})`;
                                alert(data.message || (data.favorited ?
                                    'Đã thêm vào yêu thích' : 'Đã xóa khỏi yêu thích'));
                            } else {
                                alert(data.message || 'Đã có lỗi xảy ra');
                            }
                        })
                        .catch(error => {
                            console.error('Fetch Error:', error);
                            alert('Lỗi khi thêm/xóa yêu thích. Vui lòng thử lại.');
                        });
                });
            });
        });
        document.querySelectorAll('.btn-remove-favorite').forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                const id_bienthe = this.getAttribute('data-id');
                const url = this.getAttribute('data-url');

                fetch(`<?php echo e(route('yeuthich.remove')); ?>`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        body: JSON.stringify({
                            id_bienthe,
                            url
                        })
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            alert(data.message || 'Đã xóa khỏi yêu thích');
                            this.closest('.col-md-3').remove();

                            // Reload nếu hết danh sách
                            if (!document.querySelector('.col-md-3')) {
                                window.location.reload();
                            }

                            document.querySelector('#favorites-count').textContent =
                                `(${data.favoritesCount || 0})`;
                        } else {
                            alert(data.message || 'Không thể xóa sản phẩm này');
                        }
                    })
                    .catch(err => {
                        console.error(err);
                        alert('Lỗi khi xóa khỏi yêu thích.');
                    });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Profile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/op6cjaieob0f/public_html/resources/views/profile/MyProduct.blade.php ENDPATH**/ ?>